# car_emissions
- This project discusses the the cars that cause air pollution by emitting carbon 
- For interactive visuals : https://www.novypro.com/project/car-emissions
