# udemy_courses
- This one discusses some almost all the parameters of Udemy courses since 2010 until 2021
- I'm sorry I couldn't upload the dataset because it's too big (70 MB)
- For interactive visuals : https://www.novypro.com/project/udemy-courses
