# Weather
- It's a project that explores a time-series for weather condition every hour of the days of 2012
- For interactive visuals : https://www.novypro.com/project/weather
