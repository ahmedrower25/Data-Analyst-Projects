# Children-s_mortality
- This code analyzes a data for children's mortality rate in different countries since 1990 until 2019
- For interactive visuals : https://www.novypro.com/project/childrens-mortality
