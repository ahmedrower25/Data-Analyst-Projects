# Traffic_Violations
- This code is an analysis to a data that describes the police stopping vehicles for traffic violations 
- For interactive visuals : https://www.novypro.com/project/traffic-violations
